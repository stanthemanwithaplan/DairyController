package uk.co.somestuff.westfalia.interceptor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ADIS {

    private ArrayList<Cow> cattle = new ArrayList<Cow>();

    private static class Status {
        public static String DN = "DN";
        public static String VN = "VN";
        public static String TN = "TN";
        public static String ZN = "ZN";
    }

    private static class DefinitionType {
        public static int Responder1 = 2023;
        public static int Name = 2003;
        public static int Group = 2021;
        public static int Cow = 2001;
        public static int Registration1 = 2002;
    }

    private class Definition {
        private int definition;
        private int width;

        public Definition(int definition, int width) {
            this.definition = definition;
            this.width = width;
        }

        public int getDefinition() {
            return this.definition;
        }

        public int getWidth() {
            return this.width;
        }
    }

    public ADIS(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));

        ArrayList<Definition> definitions = new ArrayList<Definition>();

        try {
            String line = br.readLine();
            while (line != null) {

                String lineStatus = line.substring(0, 2);
                String lineData = line.substring(2);

                if (lineStatus.equals(Status.DN)) {

                    String data = lineData.substring(10); // Removing the initial 10 '0's

                    while (data.length() > 0) {
                        String workingDefinition = data.substring(0, 6);
                        String definitionType = workingDefinition.substring(0, 4);
                        Definition definition = new Definition(Integer.parseInt(definitionType), Integer.parseInt(workingDefinition.substring(4)));
                        definitions.add(definition);
                        data = data.substring(7);
                        if (data.length() >= 4) {
                            data = data.substring(4);
                        }
                    }
                } else if (lineStatus.equals(Status.VN)) {
                    String data = lineData.substring(6);

                    Cow cow = new Cow();

                    while (data.length() >= 6) {
                        for (int i = 0; i < definitions.size(); i++) {
                            if (definitions.get(i).definition == DefinitionType.Responder1) {
                                cow.setResponder1(data.substring(0, definitions.get(i).width));
                            } else if (definitions.get(i).definition == DefinitionType.Name) {
                                cow.setName(data.substring(0, definitions.get(i).width));
                            } else if (definitions.get(i).definition == DefinitionType.Group) {
                                cow.setGroup(data.substring(0, definitions.get(i).width));
                            } else if (definitions.get(i).definition == DefinitionType.Cow) {
                                cow.setUid(data.substring(0, definitions.get(i).width));
                            } else if (definitions.get(i).definition == DefinitionType.Registration1) {
                                cow.setRegistration1(data.substring(0, definitions.get(i).width));
                            }

                            data = data.substring(definitions.get(i).width);
                        }
                    }

                    this.cattle.add(cow);

                }
                line = br.readLine();
            }
        } finally {
            br.close();
        }
    }

    public ArrayList<Cow> getCattle() {
        return this.cattle;
    }
}
