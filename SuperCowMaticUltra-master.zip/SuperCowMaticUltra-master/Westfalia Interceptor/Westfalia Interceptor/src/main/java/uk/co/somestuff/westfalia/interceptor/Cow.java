package uk.co.somestuff.westfalia.interceptor;

public class Cow {
    private String registration1;
    private String responder1;
    private String name;
    private String group;
    private String uid;

    public Cow() {}

    public Cow(String registration1, String responder1, String name, String group, String uid) {
        this.registration1 = registration1;
        this.responder1 = responder1;
        this.name = name;
        this.group = group;
        this.uid = uid;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegistration1(String registration1) {
        this.registration1 = registration1;
    }

    public void setResponder1(String responder1) {
        this.responder1 = responder1;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getRegistration1() {
        return this.registration1;
    }

    public String getResponder1() {
        return this.responder1;
    }

    public String getName() {
        return this.name;
    }

    public String getGroup() {
        return this.group;
    }

    public String getUid() {
        return this.uid;
    }
}
