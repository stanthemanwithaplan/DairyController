package uk.co.somestuff.westfalia.interceptor;


import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {

        ADIS adis = new ADIS("C:/Users/Stan/Desktop/SampleAnswer.ads");

        for (int i = 0; i < adis.getCattle().size(); i++) {
            System.out.println(adis.getCattle().get(i).getGroup() + ")" + adis.getCattle().get(i).getRegistration1());
        }

        if (args.length < 1) {
            System.out.println("Available COM ports:");
            for (int i = 0; i < SerialPort.getCommPorts().length; i++) {
                SerialPort serialPort = SerialPort.getCommPorts()[i];
                System.out.println(serialPort.getSystemPortName());
            }
            try {
                System.in.read();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.exit(0);
        }

        SerialPort serialPort = SerialPort.getCommPort(args[0]);

        boolean serialPortExists = false;

        for (int i = 0; i < SerialPort.getCommPorts().length; i++) {
            if (SerialPort.getCommPorts()[i].getSystemPortName().equals(args[0])) {
                serialPortExists = true;
                break;
            }
        }

        if (args.length >= 2) {
            if (!serialPortExists && args[1].equals("-w")) {
                while (!serialPortExists) {
                    System.out.print("(" + Instant.now().getEpochSecond() + ") Checking for '" + args[0] + "'");
                    for (int i = 0; i < SerialPort.getCommPorts().length; i++) {
                        if (SerialPort.getCommPorts()[i].getSystemPortName().equals(args[0])) {
                            serialPortExists = true;
                            break;
                        }
                    }
                    if (!serialPortExists) {
                        System.out.println(" [Not found]");
                    }
                    Thread.sleep(500);
                }
            }
        }

        if (!serialPortExists) {
            System.out.println("Serial port '" + args[0] + "' doesn't exist");
            System.exit(0);
        }


        serialPort.setBaudRate(4800);
        serialPort.setParity(SerialPort.EVEN_PARITY);
        serialPort.setNumStopBits(SerialPort.TWO_STOP_BITS);
        serialPort.setNumDataBits(7);
        serialPort.openPort();

        while (true) {

            /** Getting the current status of the device **/
            write(serialPort, (byte) 0x20);
            SerialResponse res = read(serialPort);

            if (res.getByte() == (byte) 0x53) {
                /** A Tag is ready to be read **/
                write(serialPort, (byte) 0x07);
                res = read(serialPort);

                if (res.getByte() == (byte) 0x07) {
                    System.out.println("Acknowledgment acknowledged");

                    write(serialPort, (byte) 0x0d);

                    StringBuilder tag = new StringBuilder();

                    for (int i = 0; i < 4; i++) {
                        res = read(serialPort);
                        tag.append(res.getString());
                        write(serialPort, res.getByte());
                    }

                    System.out.println("Tag read '" + tag + "'");


                    /** Now we shed or don't shed it **/

                    if (!tag.toString().equals("8701")) {
                        write(serialPort, (byte) 0x20);
                        Thread.sleep(500);
                        write(serialPort, (byte) 0x20);
                        Thread.sleep(500);
                        write(serialPort, (byte) 0x42);
                    }

                }
            }

            Thread.sleep(500);
        }

        //serialPort.closePort();

    }

    private static SerialResponse read(SerialPort serialPort) {
        while (serialPort.bytesAvailable() == 0) {
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        byte[] readBuffer = new byte[serialPort.bytesAvailable()];
        serialPort.readBytes(readBuffer, readBuffer.length);

        try {
            SerialResponse serialResponse = new SerialResponse(readBuffer);
            System.out.println("(" + Instant.now().getEpochSecond() + ") Rx: 0x" + serialResponse.getHex() + " (" + serialResponse.getString() + ")");
            return serialResponse;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return null;
    }

    private static void write(SerialPort serialPort, byte b) {
        byte[] sendData = new byte[]{(byte) b};
        serialPort.writeBytes(sendData, sendData.length);
        System.out.println("(" + Instant.now().getEpochSecond() + ") Tx: 0x" + byteArrayToString(sendData));
    }

    private static String byteArrayToString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }

        return sb.toString();
    }
}
