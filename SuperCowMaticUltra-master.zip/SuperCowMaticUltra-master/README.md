# SuperCowMaticUltra

## Protocol Notes

* Some ports run at 1200, some at 4800.  4800 format is 7 bits, even parity, 2 stop bits
* Send 0x20 to request status, unit returns:
- 0x50 Asleep?
- 0x51 Ready, idle
- 0x53 Tag ready to read
- (It may be that bit 0 is "OnLine" and bit 1 is "TagWaiting")
- Timeout on receiving data is needed as bytes often get "lost" in prolonged use, 2000ms timeout seems to work well

### Waking the device
- Not to sure what it means but sending "00000001000000", "CWT3SDW412p2", "1007000000000210", "CWT3SDW412p2" wakes the device it looks like "CWT3SDW412p2" is the possible address of the device and the 1s, 0s, 7s are parameters for the device?

### To read tag:

- Send 0x07 and wait for unit to sent 0x07 as ACK
- Send 0x0d, unit will send first char of tag
- Acknowledge each tag char by echoing it back to unit
- After reading four digits of tag, unit will clear bit 1 from the status byte
- The unit will send 0x0d when the tage has finished being sent

### Request shedding:

 - After reading tag, send 'B' (0x41)
 - Then there's some stuff with another 0x0d which we haven't worked out yet
 - The worked out stuff
 - After repeating the tag back to the unit the bytes shoud be returned with time for a response where commars are placed {0x20, 0x20, 0x42 0x20, 0x06, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x0d 0x20 } (not sure if the initial two 0x20 are needed or the software just sends these while it searches the db)
 - This will shed the cow, if shedding isn't required no response other than the recived tag is needed
 
## Issues:

- There's some kind of problem where the device will read the cow twice and close the initial gates, this wouldn't be a problem because the gate doesn't stay closed for long but it scares the other cows slowing the whole milking up. Could be a fault in reading the tag or not sending a properly saying we've read it?

