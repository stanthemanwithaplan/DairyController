﻿using System;
using System.Text;
using System.Threading.Tasks;

namespace WinCowGate
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using (var port = new VCPort("COM8"))
            {
                for (;;)
                {
                    var statusFlags = await ReadStatusFlags(port);
                    if ((statusFlags.flags & 0x02) != 0)
                    {
                        Console.WriteLine("Tag Read");
                        await ReadTag(port);
                    }
                    
                    await Task.Delay(500);
                }
            }
        }

        static async Task<(byte flags, bool valid)> ReadStatusFlags(VCPort port)
        {
            port.Write(0x20);
            var statusFlags = await port.ReadByte();
            Console.WriteLine("Status: 0x{0} ('{1}')", statusFlags, (char) statusFlags.data);
            return statusFlags;
        }

        static async Task ReadTag(VCPort port)
        {
            port.Write(0x07);
            var ack7 = await port.ReadByte();
            Console.WriteLine("Ack {0}", ack7);

            if (!ack7.valid || ack7.data != 0x07)
            {
                Console.WriteLine("Bad ack to read command");
                return;
            }

            port.Write(0x0d);

            var tagCharacters = new StringBuilder();
            byte tagByte = 0;
            for (int index = 0; index < 4; index++)
            {
                var tagRx = await port.ReadByte();
//                            await Task.Delay(50);
                if (tagRx.valid)
                {
                    tagByte = tagRx.data;
                }

                port.Write(tagByte);
                tagCharacters.Append((char) tagByte);
            }

            Console.WriteLine("Read Tag: {0}", tagCharacters);
            if (tagCharacters.ToString() == "8340")
            {
                Console.WriteLine("Shedding tag");
                port.Send('B');
            }
        }
    }
}
