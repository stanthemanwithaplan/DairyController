﻿using System;
using System.IO.Ports;
using System.Text;
using System.Threading.Tasks;

namespace WinCowGate
{
    public class VCPort : IDisposable
    {
        readonly SerialPort _port;

        public VCPort(string portName)
        {
            _port = new SerialPort(portName, 4800, Parity.Even, 7, StopBits.Two);
        //    _port.DataReceived += PortOnDataReceived;
            _port.ReadTimeout = 2000;    
            _port.Open();
        }

        void PortOnDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (e.EventType == SerialData.Chars)
            {
                byte[] buffer = new byte[1024];
                var rxLen = _port.Read(buffer, 0, buffer.Length);
                ProcessData(buffer, rxLen);
            }
        }

        void ProcessData(byte[] buffer, int rxLen)
        {
            var s = Encoding.ASCII.GetString(buffer, 0, rxLen);
            Console.WriteLine("Rx: {0} {1}", BitConverter.ToString(buffer, 0, rxLen), s); ;
        }

        public void Dispose()
        {
            _port?.Dispose();
        }

        public void Send(char c)
        {
            Console.WriteLine("Tx: '{0}'", c);
            _port.Write(new string(c, 1));
        }

        public void Write(byte dataByte)
        {
            Console.WriteLine("Tx: 0x{0:x2}", dataByte);
            var packet = new byte[1];
            packet[0] = dataByte;
            _port.Write(packet, 0, packet.Length);
        }

        public async Task<(byte data, bool valid)> ReadByte()
        {
            try
            {
                var result = (byte) _port.ReadByte();
                Console.WriteLine("Rx: 0x{0:x2} ('{1}')", result, (char) result);
                return (result, true);
            }
            catch (TimeoutException)
            {
                return (0, false);
            }
        }
    }
}